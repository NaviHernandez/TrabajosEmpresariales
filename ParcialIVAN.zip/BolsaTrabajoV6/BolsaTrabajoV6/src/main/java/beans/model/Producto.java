package beans.model;

import java.util.Date;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Named
@RequestScoped
public class Producto {

    private String codigo;
    private String nombre;
    private int preciocomp;
    private Date fechaNacimiento;
    private String descripcion;
    private String precioventa;
    private String ciudad;
    private String comentario;

    Logger log = LogManager.getRootLogger();

    public Producto() {
        log.info("Creando el Producto");
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
        log.info("Modificando el Codigo del Producto:" + this.codigo);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
        log.info("Modificando el Nombre del Producto:" + this.nombre);
    }

    public int getPreciocomp() {
        return preciocomp;
    }

    public void setPreciocomp(int preciocomp) {
        this.preciocomp = preciocomp;
        log.info("Modificando el Precio de Compra del Producto" + this.preciocomp);
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getPrecioventa() {
        return precioventa;
    }

    public void setPrecioventa(String precioventa) {
        this.precioventa = precioventa;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }
}
