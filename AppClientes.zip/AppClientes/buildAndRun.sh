#!/bin/sh
mvn clean package && docker build -t com.uts.edu.co/AppClientes .
docker rm -f AppClientes || true && docker run -d -p 9080:9080 -p 9443:9443 --name AppClientes com.uts.edu.co/AppClientes